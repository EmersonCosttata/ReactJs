import '../App.css'; 
import logo from '../logo.png';

const Header = () => {

  return (
    <header className="header" >
    <div className="buttons">
     <button>...</button>
     <button>Procurar</button>  
    </div>
    <div className="logo"><img src={logo}></img></div>
  </header>
  );

};

export default Header;