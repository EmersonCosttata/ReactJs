import React from 'react'
import Galery from './Galery'

const Section = ({nomeSessao,images}) =>{
    
   

    return (
    <div className="section">
        <h2> {nomeSessao}</h2>
        <Galery images={images}></Galery>
    </div>
  )
}

export default Section