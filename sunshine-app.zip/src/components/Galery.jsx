import React from 'react';
import '../App'; 
import ScrollReveal from 'scrollreveal'
const Galery = ({ images }) => {
  ScrollReveal().reveal('.galery',{ delay: 400, reset: true });
  return (
    <div className="galery">
      {images.map((image, index) => (
        <a href=''><img key={index} src={image} alt={`media ${index + 1}`} /></a>
      ))}
    </div>
  );
};

export default Galery;